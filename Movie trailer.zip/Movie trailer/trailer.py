import fresh_tomatoes
import media


# wonder women: movie name, story line, poster image, trailer
wonder_women = media.Movie(
"WONDER WOMEN",
"A story of the princess of Amazons",
"https://upload.wikimedia.org/wikipedia/en/e/ed/Wonder_Woman_%282017_film%29.jpg",  # NOQA
"https://www.youtube.com/watch?v=1Q8fG0TtVAY")

# harry potter: movie name, story line, poster image, trailer
harry_potter = media.Movie(
"HARRY POTTER",
"The fantasy world",
"https://upload.wikimedia.org/wikipedia/en/d/df/Harry_Potter_and_the_Deathly_Hallows_%E2%80%93_Part_2.jpg",  # NOQA
"https://www.youtube.com/watch?v=_EC2tmFVNNE")
# bahubali 2: movie name, story line, poster image, trailer
bahubali2 = media.Movie(
"BAHUBALI 2 THE CONCLUSION",
"The answer for why did kattapa kill bahubali",
"https://upload.wikimedia.org/wikipedia/en/f/f9/Baahubali_the_Conclusion.jpg",  # NOQA
"https://www.youtube.com/watch?v=94BzBOpv42g")
# annabelle creation: movie name, story line, poster image, trailer
annabelle_creation = media.Movie(
"ANNABELLE CREATION",
"Get ready for the horror",
"https://upload.wikimedia.org/wikipedia/en/0/08/Annabelle_Creation.jpg",  # NOQA
"https://www.youtube.com/watch?v=KisPhy7T__Q")
# despicable me 3: movie name, story line, poster image, trailer
despicable_me_3 = media.Movie(
"DESPICABLE ME 3",
"The minions story",
"https://upload.wikimedia.org/wikipedia/en/9/91/Despicable_Me_3_%282017%29_Teaser_Poster.jpg",  # NOQA
"https://www.youtube.com/watch?v=6DBi41reeF0")
# fantastic beasts: movie name, story line, poster image, trailer
fantastic_beasts = media.Movie(
"FANTASTIC BEASTS",
"The harry potter extended",
"https://upload.wikimedia.org/wikipedia/en/5/5e/Fantastic_Beasts_and_Where_to_Find_Them_poster.png",  # NOQA
"https://www.youtube.com/watch?v=0_DNCfYDWqw")
# assigning list of movies
movies = [wonder_women, harry_potter, bahubali2, annabelle_creation, despicable_me_3, fantastic_beasts]  # NOQA
# calling the movies function
fresh_tomatoes.open_movies_page(movies)
