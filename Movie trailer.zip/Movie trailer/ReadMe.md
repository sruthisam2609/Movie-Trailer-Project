*This project is a web application*

This application provides the users to view the movie posters and trailers.

#INSTALLATION
To install the __Movie_Trailer_Website__ files, Just download the zip files
For instruction on installing Python 2.7 Interpreter,
please check out the [Installation manual]("https://docs.python.org/2/install/index.html")

#EXECUTION
open the terminal. Move to the specified directory where your project folder is situated.
Execute the python file using the syntax given below.
python <file_name>.py
python trailer.py
The command prompt display the report message
The new window will be opened in the existing browser.

NOTE:
The trailer.py class contains the movie details 


